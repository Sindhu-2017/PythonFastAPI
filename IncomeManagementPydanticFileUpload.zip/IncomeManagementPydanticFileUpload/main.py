from fastapi import FastAPI
from routers.income_router import router as income_router
from routers.expense_attachment_router import router as attachment_router

app = FastAPI(
    title="Income Management API",
    description="API for managing income, expenses and cash in hand",
    version="1.0.0"
)
app.include_router(income_router)
app.include_router(attachment_router)


@app.get("/")
def home():
    return {
        "message": "Income Management API is running"
    }